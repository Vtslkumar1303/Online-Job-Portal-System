from django.contrib import admin
from jobsapp.models import Job,Applicant

admin.site.register([Job,Applicant])
# Register your models here.
