from django.apps import AppConfig


class JobsappConfig(AppConfig):
    name = 'jobsapp'
