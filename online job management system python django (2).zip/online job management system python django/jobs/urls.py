from django.contrib import admin
from django.urls import path, include

from accounts.views import AboutView,ContactView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('aboutus/', AboutView.as_view()),
    path('contactus/', ContactView.as_view()),
    path('', include('jobsapp.urls')),
    path('', include('accounts.urls')),
    
]